# EmployeeMgmt

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 11.0.0.
The application allows the user to perform basic CRUD operation that are carried out in an Employee management software. 
The application has to authorization access i.e 'User' and 'Admin'. 
Admin can add a new employee and the new employee can then login to the system using email ID and the initial password be in the pattern firstnamelastname.

## Development server

Run `npm start` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## JSON Server

Run `npm run db:server` to start JSON server for data.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `--prod` flag for a production build.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via [Protractor](http://www.protractortest.org/).

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI Overview and Command Reference](https://angular.io/cli) page.
