import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-newcmp',
  templateUrl: './newcmp.component.html',
  styleUrls: ['./newcmp.component.css']
})
export class NewcmpComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
